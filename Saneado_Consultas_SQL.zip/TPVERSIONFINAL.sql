-------------------------------------
-- MIGRACION DE DATOS
----------------------------

CREATE TABLE Migracion (
    -- Datos del equipo oponente
    OPcity VARCHAR(100),
    OPcode VARCHAR(50),
    OPsigla VARCHAR(10),
    OPConference VARCHAR(50),
    OPdivision VARCHAR(50),
    OPid BIGINT,
    OPname VARCHAR(100),
    
    -- Estad�sticas de asistencias
    stat_asistencias_id INT,
    stat_asistencias_nombre VARCHAR(100),
    stat_asistencias_valor DECIMAL(10,2),
    
    -- Estad�sticas de bloqueos
    stat_blocks_id INT,
    stat_blocks_nombre VARCHAR(100),
    stat_blocks_valor DECIMAL(10,2),
    
    -- Datos del jugador
    city VARCHAR(100),
    codeJug VARCHAR(100),
    country VARCHAR(100),
    
    -- Estad�sticas de rebotes defensivos
    stat_defrebs_id INT,
    stat_defrebs_nombre VARCHAR(100),
    stat_defrebs_valor DECIMAL(10,2),
    
    -- Datos del equipo
    sigla VARCHAR(10),
    Conference VARCHAR(50),
    NamePlayer VARCHAR(200),
    division VARCHAR(50),
    draftYear INT,
    fecha DATE,
    
    -- Estad�sticas de tiros de campo
    stat_fga_id INT,
    stat_fga_nombre VARCHAR(100),
    stat_fga_valor DECIMAL(10,2),
    stat_fgm_id INT,
    stat_fgm_nombre VARCHAR(100),
    stat_fgm_valor DECIMAL(10,2),
    fgpct DECIMAL(5,2),
    
    -- Nombre del jugador
    firstName VARCHAR(100),
    
    -- Estad�sticas de faltas
    stat_fouls_id INT,
    stat_fouls_nombre VARCHAR(100),
    stat_fouls_valor DECIMAL(10,2),
    
    -- Estad�sticas de tiros libres
    stat_fta_id INT,
    stat_fta_nombre VARCHAR(100),
    stat_fta_valor DECIMAL(10,2),
    stat_ftm_id INT,
    stat_ftm_nombre VARCHAR(100),
    stat_ftm_valor DECIMAL(10,2),
    ftpct DECIMAL(5,2),
    
    -- Datos del partido
    gameId BIGINT,
    height VARCHAR(20),
    isHome BIT,
    jerseyNo DECIMAL(5,1),
    lastName VARCHAR(100),
    
    -- Estad�sticas de minutos
    stat_mins_id INT,
    stat_mins_nombre VARCHAR(100),
    stat_mins_valor DECIMAL(10,2),
    
    name VARCHAR(100),
    
    -- Estad�sticas de rebotes ofensivos
    stat_offrebs_id INT,
    stat_offrebs_nombre VARCHAR(100),
    stat_offrebs_valor DECIMAL(10,2),
    
    -- Puntuaciones
    oppTeamScore INT,
    playerId BIGINT,
    
    -- Estad�sticas de puntos
    stat_points_id INT,
    stat_points_nombre VARCHAR(100),
    stat_points_valor DECIMAL(10,2),
    
    position VARCHAR(10),
    rebs DECIMAL(10,2),
    seasonId INT,
    
    -- Estad�sticas de segundos
    stat_secs_id INT,
    stat_secs_nombre VARCHAR(100),
    stat_secs_valor DECIMAL(10,2),
    
    -- Estad�sticas de robos
    stat_steals_id INT,
    stat_steals_nombre VARCHAR(100),
    stat_steals_valor DECIMAL(10,2),
    
    -- Datos del equipo
    teamCode VARCHAR(50),
    teamScore INT,
    teamid BIGINT,
    
    -- Estad�sticas de triples
    stat_tpa_id INT,
    stat_tpa_nombre VARCHAR(100),
    stat_tpa_valor DECIMAL(10,2),
    stat_tpm_id INT,
    stat_tpm_nombre VARCHAR(100),
    stat_tpm_valor DECIMAL(10,2),
    tppct DECIMAL(5,2),
    
    -- Estad�sticas de p�rdidas
    stat_turnovers_id INT,
    stat_turnovers_nombre VARCHAR(100),
    stat_turnovers_valor DECIMAL(10,2),
    
    weight VARCHAR(20),
    winOrLoss VARCHAR(10),
    yearDisplay VARCHAR(20),
    
    -- Identificadores adicionales
    idPais INT,
    idCity INT,
    OPidCity INT,
);

-- Cambiar BIT por VARCHAR temporalmente
ALTER TABLE Migracion ALTER COLUMN isHome VARCHAR(10);

-- Cambiar de DECIMAL(5,1) a INT
ALTER TABLE Migracion ALTER COLUMN jerseyNo FLOAT;
ALTER TABLE Migracion ALTER COLUMN tppct FLOAT

BULK INSERT Migracion
FROM 'C:\Windows\Temp\datos_definitivo_2 - datos_definitivo_2.csv (1).csv'
WITH (
    FIELDTERMINATOR = ',',
    ROWTERMINATOR   = '\n',
    FIRSTROW = 2,
 CODEPAGE = '65001' -- UTF-8 (acentos y palabras en espa�ol)
);

------------------------------------------
-- CREACION DE TABLAS
----------------------------------------

-- TABLA CONFERENCIA
create table Conferencia 
(ID_Conferencia INT, 
Nombre_Conferencia VARCHAR(100) NOT NULL,
CONSTRAINT [PK_IDC] PRIMARY KEY CLUSTERED (ID_Conferencia))

--TABLA CIUDAD
CREATE TABLE CIUDAD
( ID_Ciudad INT NOT NULL,
  Nombre_Ciudad VARCHAR (50),
  CONSTRAINT [PK_Ciudad] PRIMARY KEY CLUSTERED (ID_Ciudad))

--TABLA PAIS
create table Pais (
ID_pais int primary KEY, 
Nom_Pais varchar(100) not null);

--TABLA DIVISION
CREATE TABLE Division
(    ID_Division INT NOT NULL,
    Nombre_Division VARCHAR (50),
    Conferencia_D INT NOT NULL,
    CONSTRAINT [PK_Division] PRIMARY KEY CLUSTERED (ID_Division),
    CONSTRAINT [FK_Conferencia_Div] FOREIGN KEY (Conferencia_D) REFERENCES Conferencia (ID_Conferencia))

--TABLA EQUIPO
CREATE TABLE EQUIPO
(ID_Equipo INT NOT NULL,
Code_Alfa VARCHAR(200) NOT NULL,
Nombre_Equipo VARCHAR(200) NOT NULL,
Sigla VARCHAR(3) NOT NULL,
Ciudad_E INT NOT NULL,
Div_Equipo INT NOT NULL,
CONSTRAINT [PK_IDE] PRIMARY KEY CLUSTERED (ID_Equipo),
CONSTRAINT [FK_Ciudad_Equipo] FOREIGN KEY (Ciudad_E) REFERENCES CIUDAD(ID_Ciudad),
CONSTRAINT [FK_Div_Equipo] FOREIGN KEY (Div_Equipo) REFERENCES Division (ID_Division))

--TABLA JUGADOR
CREATE TABLE JUGADOR
(ID_Jugador INT NOT NULL,
Codigo_Alfabetico VARCHAR(20) NOT NULL,
Nombre_Jugador VARCHAR(50) NOT NULL,
Apellido_Jugador VARCHAR(50) NOT NULL,
Altura_Jugador FLOAT NULL,
Peso_Jugador FLOAT NULL,
Posicion_Jugador VARCHAR(20) NULL,
DraftYear INT NULL,
Pais_origen INT NULL,
Equipo_Jugador INT NULL,
CONSTRAINT [PK_IDJ] PRIMARY KEY CLUSTERED (ID_Jugador),
CONSTRAINT [FK_Pais_Jugador] FOREIGN KEY (Pais_Origen) REFERENCES PAIS(ID_Pais),
CONSTRAINT [FK_Equipo_Jugador] FOREIGN KEY (Equipo_Jugador) REFERENCES EQUIPO (ID_Equipo))

--TABLA ESTADISTICA
CREATE TABLE Tipo_Estadistica (
ID_Estadistica INT NOT NULL, 
Desc_Est varchar(100) not null,
CONSTRAINT [PK_TE] PRIMARY KEY CLUSTERED (ID_Estadistica))

--TABLA TEMPORADA
CREATE TABLE TEMPORADA
(ID_Temporada INT NOT NULL,
Temp_Descripcion VARCHAR(200) NULL,
CONSTRAINT [PK_IDT] PRIMARY KEY CLUSTERED (ID_Temporada))

--TABLA PARTIDO 
CREATE TABLE Partido
(    ID_Partido INT NOT NULL,
    Partido_Local VARCHAR (50),
    Partido_Visitante VARCHAR (50),
    Fecha_Partido DATE,
    Puntos_Local INT NOT NULL,
    Puntos_Visitante INT NOT NULL,
    Ganador VARCHAR(50),
    Temporada_V INT NOT NULL,
    Jugador_V INT NOT NULL,
    Equipo_V INT NOT NULL,
    CONSTRAINT [PK_PARTIDO] PRIMARY KEY CLUSTERED (ID_Partido),
    CONSTRAINT [FK_Temporada_Partido] FOREIGN KEY (Temporada_V) REFERENCES Temporada (ID_Temporada),
    CONSTRAINT [FK_Jugador_Partido] FOREIGN KEY (Jugador_V) REFERENCES Jugador (ID_Jugador),
    CONSTRAINT [FK_Equipo_Partido] FOREIGN KEY (Equipo_V) REFERENCES Equipo (ID_Equipo))

-- TABLA STATS
CREATE TABLE STATABLE (
    Cantidad INT,  
    Jugador_S INT NOT NULL,
    Estadistica_S INT NOT NULL,
    Partido_S INT NOT NULL,
    CONSTRAINT [PK_Stats] PRIMARY KEY CLUSTERED (Jugador_S, Estadistica_S, Partido_S),  
    CONSTRAINT [FK_ID_J_Stats] FOREIGN KEY (Jugador_S) REFERENCES Jugador(ID_Jugador),
    CONSTRAINT [FK_ID_Est_Stats] FOREIGN KEY (Estadistica_S) REFERENCES Tipo_Estadistica(ID_Estadistica),
    CONSTRAINT [FK_ID_P_Stats] FOREIGN KEY (Partido_S) REFERENCES Partido(ID_Partido)
)

--TABLA JUGADOR-EQUIPO
CREATE TABLE Jugador_Equipo (
    Nro_Camiseta INT,
    ID_Jugador INT NOT NULL,
    ID_Equipo INT NOT NULL,
    CONSTRAINT [PK_J_E] PRIMARY KEY CLUSTERED(ID_Jugador,ID_Equipo),
    CONSTRAINT [FK_ID_J_JE] FOREIGN KEY (ID_Jugador) REFERENCES Jugador(ID_Jugador),
    CONSTRAINT [FK_ID_E_JE] FOREIGN KEY (ID_Equipo) REFERENCES Equipo(ID_Equipo)  
)

--TABLA JUGADOR-TEMP
CREATE TABLE Jugador_Temporada(
    ID_Jugador INT NOT NULL,
    ID_Temporada INT NOT NULL,
    CONSTRAINT [PK_J_T] PRIMARY KEY CLUSTERED(ID_Jugador,ID_Temporada),
    CONSTRAINT [FK_ID_J_JT] FOREIGN KEY (ID_Jugador) REFERENCES Jugador(ID_Jugador),
    CONSTRAINT [FK_ID_T_JT] FOREIGN KEY (ID_Temporada) REFERENCES Temporada(ID_Temporada)
)

-----------------------------------------//
-- CARGA DE DATOS
----------------------------------------------//

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRAN;

    /* =========================================================
                       CONFERENCIA 
       ========================================================= */
    ;WITH ConfSrc AS (
        SELECT LTRIM(RTRIM(Conference)) AS Nombre FROM Migracion
        UNION
        SELECT LTRIM(RTRIM(OPConference)) FROM Migracion
    ),
    ConfMap AS (
        SELECT DENSE_RANK() OVER(ORDER BY Nombre) AS ID_Conferencia,
               Nombre AS Nombre_Conferencia
        FROM (SELECT DISTINCT Nombre
              FROM ConfSrc
              WHERE Nombre IS NOT NULL AND Nombre <> '') x
    )
    INSERT INTO Conferencia (ID_Conferencia, Nombre_Conferencia)
    SELECT c.ID_Conferencia, c.Nombre_Conferencia
    FROM ConfMap c
    LEFT JOIN Conferencia t ON t.ID_Conferencia = c.ID_Conferencia
    WHERE t.ID_Conferencia IS NULL;

    /* ==========================================
                         PAIS
       ========================================== */
    ;WITH P AS (
        SELECT
            TRY_CAST(idPais AS INT)              AS ID_Pais,
            NULLIF(LTRIM(RTRIM(country)), '')    AS Nom_Pais
        FROM Migracion
        WHERE TRY_CAST(idPais AS INT) IS NOT NULL
    ),
    RankedPais AS (
        SELECT
            ID_Pais,
            LEFT(Nom_Pais, 100) AS Nom_Pais,
            ROW_NUMBER() OVER (
                PARTITION BY ID_Pais
                ORDER BY CASE WHEN Nom_Pais IS NULL THEN 1 ELSE 0 END, Nom_Pais
            ) AS rn
        FROM P
    )
    INSERT INTO Pais (ID_Pais, Nom_Pais)
    SELECT r.ID_Pais, r.Nom_Pais
    FROM RankedPais r
    WHERE r.rn = 1
      AND NOT EXISTS (SELECT 1 FROM Pais p WHERE p.ID_Pais = r.ID_Pais);

    /* ==========================================
                        CIUDAD
       ========================================== */
    -- idCity/city
    ;WITH C AS (
        SELECT
            TRY_CAST(idCity AS INT)                 AS ID_Ciudad,
            NULLIF(LTRIM(RTRIM(city)), '')          AS Nombre_Ciudad
        FROM Migracion
        WHERE TRY_CAST(idCity AS INT) IS NOT NULL
    ),
    RankedCity AS (
        SELECT
            ID_Ciudad,
            LEFT(Nombre_Ciudad, 50) AS Nombre_Ciudad,
            ROW_NUMBER() OVER (
                PARTITION BY ID_Ciudad
                ORDER BY CASE WHEN Nombre_Ciudad IS NULL THEN 1 ELSE 0 END, Nombre_Ciudad
            ) AS rn
        FROM C
    )
    INSERT INTO CIUDAD (ID_Ciudad, Nombre_Ciudad)
    SELECT r.ID_Ciudad, r.Nombre_Ciudad
    FROM RankedCity r
    WHERE r.rn = 1
      AND NOT EXISTS (SELECT 1 FROM CIUDAD x WHERE x.ID_Ciudad = r.ID_Ciudad);

    -- OPidCity/OPcity
    ;WITH C2 AS (
        SELECT
            TRY_CAST(OPidCity AS INT)               AS ID_Ciudad,
            NULLIF(LTRIM(RTRIM(OPcity)), '')        AS Nombre_Ciudad
        FROM Migracion
        WHERE TRY_CAST(OPidCity AS INT) IS NOT NULL
    ),
    RankedCity2 AS (
        SELECT
            ID_Ciudad,
            LEFT(Nombre_Ciudad, 50) AS Nombre_Ciudad,
            ROW_NUMBER() OVER (
                PARTITION BY ID_Ciudad
                ORDER BY CASE WHEN Nombre_Ciudad IS NULL THEN 1 ELSE 0 END, Nombre_Ciudad
            ) AS rn
        FROM C2
    )
    INSERT INTO CIUDAD (ID_Ciudad, Nombre_Ciudad)
    SELECT r.ID_Ciudad, r.Nombre_Ciudad
    FROM RankedCity2 r
    WHERE r.rn = 1
      AND NOT EXISTS (SELECT 1 FROM CIUDAD x WHERE x.ID_Ciudad = r.ID_Ciudad);

    /* ===========================================================
                                DIVISION
       =========================================================== */
    ;WITH ConfSrc AS (
        SELECT LTRIM(RTRIM(Conference)) AS Nombre FROM Migracion
        UNION
        SELECT LTRIM(RTRIM(OPConference)) FROM Migracion
    ),
    ConfMap AS (
        SELECT DENSE_RANK() OVER(ORDER BY Nombre) AS ID_Conferencia,
               Nombre
        FROM (SELECT DISTINCT Nombre
              FROM ConfSrc
              WHERE Nombre IS NOT NULL AND Nombre <> '') x
    ),
    DivSrc AS (
        SELECT DISTINCT LTRIM(RTRIM(division))   AS Nombre_Division,
                        LTRIM(RTRIM(Conference)) AS Nombre_Conf
        FROM Migracion
        UNION
        SELECT DISTINCT LTRIM(RTRIM(OPdivision)),
                        LTRIM(RTRIM(OPConference))
        FROM Migracion
    ),
    DivMap AS (
        SELECT DENSE_RANK() OVER(ORDER BY Nombre_Division, Nombre_Conf) AS ID_Division,
               Nombre_Division,
               Nombre_Conf
        FROM (SELECT *
              FROM DivSrc
              WHERE Nombre_Division IS NOT NULL AND Nombre_Division <> ''
             ) z
    )
    INSERT INTO Division (ID_Division, Nombre_Division, Conferencia_D)
    SELECT d.ID_Division,
           d.Nombre_Division,
           c.ID_Conferencia
    FROM DivMap d
    JOIN ConfMap c ON c.Nombre = d.Nombre_Conf
    LEFT JOIN Division t ON t.ID_Division = d.ID_Division
    WHERE t.ID_Division IS NULL;

    /* ==========================================
                    EQUIPO
       ========================================== */
    ;WITH ConfSrc AS (
        SELECT LTRIM(RTRIM(Conference)) AS Nombre FROM Migracion
        UNION SELECT LTRIM(RTRIM(OPConference)) FROM Migracion
    ),
    ConfMap AS (
        SELECT DENSE_RANK() OVER(ORDER BY Nombre) AS ID_Conferencia, Nombre
        FROM (SELECT DISTINCT Nombre
              FROM ConfSrc
              WHERE Nombre IS NOT NULL AND Nombre <> '') x
    ),
    DivSrc AS (
        SELECT DISTINCT LTRIM(RTRIM(division))   AS Nombre_Division,
                        LTRIM(RTRIM(Conference)) AS Nombre_Conf
        FROM Migracion
        UNION
        SELECT DISTINCT LTRIM(RTRIM(OPdivision)),
                        LTRIM(RTRIM(OPConference))
        FROM Migracion
    ),
    DivMap AS (
        SELECT DENSE_RANK() OVER(ORDER BY Nombre_Division, Nombre_Conf) AS ID_Division,
               Nombre_Division, Nombre_Conf
        FROM DivSrc
    ),
    AllTeamsRaw AS (
        SELECT DISTINCT
            TRY_CAST(teamid AS INT)            AS ID_Equipo,
            NULLIF(LTRIM(RTRIM(teamCode)),'')  AS Code_Alfa,
            NULLIF(LTRIM(RTRIM(name)),'')      AS Nombre_Equipo,
            LEFT(LTRIM(RTRIM(sigla)),3)        AS Sigla,
            TRY_CAST(idCity AS INT)            AS Ciudad_E,
            LTRIM(RTRIM(division))             AS Nombre_Div,
            LTRIM(RTRIM(Conference))           AS Nombre_Conf
        FROM Migracion
        WHERE TRY_CAST(teamid AS INT) IS NOT NULL
        UNION ALL
        SELECT DISTINCT
            TRY_CAST(OPid AS INT)              AS ID_Equipo,
            NULLIF(LTRIM(RTRIM(OPcode)),'')    AS Code_Alfa,
            NULLIF(LTRIM(RTRIM(OPname)),'')    AS Nombre_Equipo,
            LEFT(LTRIM(RTRIM(OPsigla)),3)      AS Sigla,
            TRY_CAST(OPidCity AS INT)          AS Ciudad_E,
            LTRIM(RTRIM(OPdivision))           AS Nombre_Div,
            LTRIM(RTRIM(OPConference))         AS Nombre_Conf
        FROM Migracion
        WHERE TRY_CAST(OPid AS INT) IS NOT NULL
    ),
    DivCounts AS (
        SELECT ID_Equipo, Nombre_Div, Nombre_Conf, COUNT(*) AS cnt
        FROM AllTeamsRaw
        GROUP BY ID_Equipo, Nombre_Div, Nombre_Conf
    ),
    BestDiv AS (
        SELECT ID_Equipo, Nombre_Div, Nombre_Conf,
               ROW_NUMBER() OVER (
                 PARTITION BY ID_Equipo
                 ORDER BY cnt DESC,
                          CASE WHEN Nombre_Div IS NULL THEN 1 ELSE 0 END, Nombre_Div,
                          CASE WHEN Nombre_Conf IS NULL THEN 1 ELSE 0 END, Nombre_Conf
               ) AS rn
        FROM DivCounts
    ),
    RowsWithBestDiv AS (
        SELECT r.*
        FROM AllTeamsRaw r
        JOIN BestDiv b
          ON b.ID_Equipo = r.ID_Equipo
         AND b.rn = 1
         AND ( (r.Nombre_Div  = b.Nombre_Div  OR (r.Nombre_Div  IS NULL AND b.Nombre_Div  IS NULL))
           AND (r.Nombre_Conf = b.Nombre_Conf OR (r.Nombre_Conf IS NULL AND b.Nombre_Conf IS NULL)) )
    ),
    PickOneTeam AS (
        SELECT
            r.*,
            ROW_NUMBER() OVER (
                PARTITION BY r.ID_Equipo
                ORDER BY
                  CASE WHEN r.Nombre_Equipo IS NULL OR r.Nombre_Equipo = '' THEN 1 ELSE 0 END,
                  LEN(r.Nombre_Equipo) DESC,
                  CASE WHEN r.Code_Alfa IS NULL OR r.Code_Alfa = '' THEN 1 ELSE 0 END,
                  LEN(r.Code_Alfa) DESC,
                  CASE WHEN r.Sigla IS NULL OR r.Sigla = '' THEN 1 ELSE 0 END,
                  CASE WHEN r.Ciudad_E IS NULL THEN 1 ELSE 0 END
            ) AS rn
        FROM RowsWithBestDiv r
    ),
    SelectedTeams AS (
        SELECT
            ID_Equipo, Code_Alfa, Nombre_Equipo, Sigla, Ciudad_E, Nombre_Div, Nombre_Conf
        FROM PickOneTeam
        WHERE rn = 1
    )
    INSERT INTO EQUIPO (ID_Equipo, Code_Alfa, Nombre_Equipo, Sigla, Ciudad_E, Div_Equipo)
    SELECT s.ID_Equipo, s.Code_Alfa, s.Nombre_Equipo, s.Sigla, s.Ciudad_E, d.ID_Division
    FROM SelectedTeams s
    JOIN DivMap d
      ON d.Nombre_Division = s.Nombre_Div AND d.Nombre_Conf = s.Nombre_Conf
    LEFT JOIN EQUIPO e ON e.ID_Equipo = s.ID_Equipo
    WHERE e.ID_Equipo IS NULL;

    /* ==========================================
                    JUGADOR 
       ========================================== */
    ;WITH PlayerRaw AS (
        SELECT
            TRY_CAST(playerId AS INT)                          AS ID_Jugador,
            LEFT(LTRIM(RTRIM(codeJug)),20)                     AS Codigo_Alfabetico,
            LEFT(LTRIM(RTRIM(firstName)),50)                   AS Nombre_Jugador,
            LEFT(LTRIM(RTRIM(lastName)),50)                    AS Apellido_Jugador,
            TRY_CAST(NULLIF(LTRIM(RTRIM(height)),'') AS FLOAT) AS Altura_Jugador,
            TRY_CAST(NULLIF(LTRIM(RTRIM(weight)),'') AS FLOAT) AS Peso_Jugador,
            LEFT(LTRIM(RTRIM(position)),20)                    AS Posicion_Jugador,
            draftYear                                          AS DraftYear,
            TRY_CAST(idPais AS INT)                            AS Pais_origen,
            TRY_CAST(teamid AS INT)                            AS Equipo_Jugador,
            fecha
    FROM Migracion
    WHERE TRY_CAST(playerId AS INT) IS NOT NULL
    ),
    PickPlayer AS (
        SELECT pr.*,
               ROW_NUMBER() OVER (
                   PARTITION BY pr.ID_Jugador
                   ORDER BY 
                       CASE WHEN pr.fecha IS NULL THEN 1 ELSE 0 END,
                       pr.fecha DESC,
                       CASE WHEN pr.Nombre_Jugador   IS NULL OR pr.Nombre_Jugador   = '' THEN 1 ELSE 0 END,
                       LEN(pr.Nombre_Jugador) DESC,
                       CASE WHEN pr.Apellido_Jugador IS NULL OR pr.Apellido_Jugador = '' THEN 1 ELSE 0 END,
                       LEN(pr.Apellido_Jugador) DESC,
                       CASE WHEN pr.Codigo_Alfabetico IS NULL OR pr.Codigo_Alfabetico = '' THEN 1 ELSE 0 END,
                       LEN(pr.Codigo_Alfabetico) DESC,
                       CASE WHEN pr.Posicion_Jugador IS NULL OR pr.Posicion_Jugador = '' THEN 1 ELSE 0 END
               ) AS rn
        FROM PlayerRaw pr
    ),
    SelectedPlayers AS (
        SELECT
            ID_Jugador, Codigo_Alfabetico, Nombre_Jugador, Apellido_Jugador,
            Altura_Jugador, Peso_Jugador, Posicion_Jugador, DraftYear, Pais_origen, Equipo_Jugador
        FROM PickPlayer
        WHERE rn = 1
    )
    INSERT INTO JUGADOR
    (ID_Jugador, Codigo_Alfabetico, Nombre_Jugador, Apellido_Jugador,
     Altura_Jugador, Peso_Jugador, Posicion_Jugador, DraftYear, Pais_origen, Equipo_Jugador)
    SELECT sp.ID_Jugador, sp.Codigo_Alfabetico, sp.Nombre_Jugador, sp.Apellido_Jugador,
           sp.Altura_Jugador, sp.Peso_Jugador, sp.Posicion_Jugador, sp.DraftYear, sp.Pais_origen, sp.Equipo_Jugador
    FROM SelectedPlayers sp
    LEFT JOIN JUGADOR j ON j.ID_Jugador = sp.ID_Jugador
    WHERE j.ID_Jugador IS NULL;

    /* ==========================================
                   TEMPORADA
       ========================================== */
    INSERT INTO TEMPORADA (ID_Temporada, Temp_Descripcion)
    SELECT DISTINCT
        TRY_CAST(seasonId AS INT) AS ID_Temporada,
        COALESCE(NULLIF(LTRIM(RTRIM(yearDisplay)),''), CONCAT('Season ', seasonId)) AS Temp_Descripcion
    FROM Migracion m
    WHERE TRY_CAST(seasonId AS INT) IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM TEMPORADA t WHERE t.ID_Temporada = TRY_CAST(m.seasonId AS INT));

    /* ==========================================
                       PARTIDO
       ========================================== */
    ;WITH GamesRaw AS (
        SELECT
            TRY_CAST(gameId AS INT)                       AS ID_Partido,
            LTRIM(RTRIM(name))                            AS NombreEquipo,
            LTRIM(RTRIM(OPname))                          AS NombreRival,
            LTRIM(RTRIM(isHome))                          AS isHome,
            LTRIM(RTRIM(winOrLoss))                       AS W_L,
            TRY_CAST(teamScore AS INT)                    AS teamScore,
            TRY_CAST(oppTeamScore AS INT)                 AS oppTeamScore,
            fecha,
            TRY_CAST(seasonId AS INT)                     AS Temporada_V,
            TRY_CAST(playerId AS INT)                     AS Jugador_V,
            TRY_CAST(teamid AS INT)                       AS Equipo_V
        FROM Migracion
        WHERE TRY_CAST(gameId AS INT) IS NOT NULL
    ),
    PickGame AS (
        SELECT gr.*,
               ROW_NUMBER() OVER (
                   PARTITION BY gr.ID_Partido
                   ORDER BY
                     CASE 
                       WHEN gr.isHome IN ('1','true','True','TRUE','home','Home','HOME') THEN 1
                       WHEN gr.isHome IN ('0','false','False','FALSE','away','Away','AWAY') THEN 2
                       ELSE 3
                     END,
                     CASE WHEN gr.fecha IS NULL THEN 1 ELSE 0 END,
                     gr.fecha DESC,
                     CASE WHEN gr.NombreEquipo IS NULL OR gr.NombreEquipo = '' THEN 1 ELSE 0 END,
                     CASE WHEN gr.NombreRival  IS NULL OR gr.NombreRival  = '' THEN 1 ELSE 0 END,
                     CASE WHEN gr.teamScore   IS NULL THEN 1 ELSE 0 END,
                     CASE WHEN gr.oppTeamScore IS NULL THEN 1 ELSE 0 END
               ) AS rn
        FROM GamesRaw gr
    ),
    OnePerGame AS (
        SELECT *
        FROM PickGame
        WHERE rn = 1
    )
    INSERT INTO Partido
    (ID_Partido, Partido_Local, Partido_Visitante, Fecha_Partido,
     Puntos_Local, Puntos_Visitante, Ganador, Temporada_V, Jugador_V, Equipo_V)
    SELECT g.ID_Partido,
           CASE WHEN g.isHome IN ('1','true','True','TRUE','home','Home','HOME')
                    THEN g.NombreEquipo ELSE g.NombreRival END AS Partido_Local,
           CASE WHEN g.isHome IN ('1','true','True','TRUE','home','Home','HOME')
                    THEN g.NombreRival ELSE g.NombreEquipo END AS Partido_Visitante,
           g.fecha AS Fecha_Partido,
           CASE WHEN g.isHome IN ('1','true','True','TRUE','home','Home','HOME')
                    THEN g.teamScore ELSE g.oppTeamScore END AS Puntos_Local,
           CASE WHEN g.isHome IN ('1','true','True','TRUE','home','Home','HOME')
                    THEN g.oppTeamScore ELSE g.teamScore END AS Puntos_Visitante,
           CASE
               WHEN g.W_L IN ('W','w','Win','WIN') THEN g.NombreEquipo
               WHEN g.W_L IN ('L','l','Loss','LOSS') THEN g.NombreRival
               ELSE CASE WHEN (g.teamScore >= g.oppTeamScore) THEN g.NombreEquipo ELSE g.NombreRival END
           END AS Ganador,
           g.Temporada_V, g.Jugador_V, g.Equipo_V
    FROM OnePerGame g
    LEFT JOIN Partido p ON p.ID_Partido = g.ID_Partido
    WHERE p.ID_Partido IS NULL;

    /* ==========================================
              TIPO_ESTADISTICA 
       ========================================== */
    ;WITH Stats AS (
        SELECT stat_asistencias_id    AS ID_Estadistica, stat_asistencias_nombre AS Desc_Est FROM Migracion
        UNION ALL SELECT stat_blocks_id,     stat_blocks_nombre     FROM Migracion
        UNION ALL SELECT stat_defrebs_id,    stat_defrebs_nombre    FROM Migracion
        UNION ALL SELECT stat_fga_id,        stat_fga_nombre        FROM Migracion
        UNION ALL SELECT stat_fgm_id,        stat_fgm_nombre        FROM Migracion
        UNION ALL SELECT stat_fouls_id,      stat_fouls_nombre      FROM Migracion
        UNION ALL SELECT stat_fta_id,        stat_fta_nombre        FROM Migracion
        UNION ALL SELECT stat_ftm_id,        stat_ftm_nombre        FROM Migracion
        UNION ALL SELECT stat_mins_id,       stat_mins_nombre       FROM Migracion
        UNION ALL SELECT stat_offrebs_id,    stat_offrebs_nombre    FROM Migracion
        UNION ALL SELECT stat_points_id,     stat_points_nombre     FROM Migracion
        UNION ALL SELECT stat_secs_id,       stat_secs_nombre       FROM Migracion
        UNION ALL SELECT stat_steals_id,     stat_steals_nombre     FROM Migracion
        UNION ALL SELECT stat_tpa_id,        stat_tpa_nombre        FROM Migracion
        UNION ALL SELECT stat_tpm_id,        stat_tpm_nombre        FROM Migracion
        UNION ALL SELECT stat_turnovers_id,  stat_turnovers_nombre  FROM Migracion
    ),
    CleanTE AS (
        SELECT DISTINCT
            TRY_CAST(ID_Estadistica AS INT)             AS ID_Estadistica,
            LEFT(LTRIM(RTRIM(Desc_Est)),100)            AS Desc_Est
        FROM Stats
        WHERE ID_Estadistica IS NOT NULL
          AND Desc_Est IS NOT NULL AND Desc_Est <> ''
    )
    INSERT INTO Tipo_Estadistica (ID_Estadistica, Desc_Est)
    SELECT c.ID_Estadistica, c.Desc_Est
    FROM CleanTE c
    LEFT JOIN Tipo_Estadistica t ON t.ID_Estadistica = c.ID_Estadistica
    WHERE t.ID_Estadistica IS NULL;

    /* ==========================================
                       STATABLE
       ========================================== */
    ;WITH S AS (
        SELECT
            TRY_CAST(playerId AS INT) AS ID_Jugador,
            TRY_CAST(gameId   AS INT) AS ID_Partido,
            stat_asistencias_id AS est_id_a, TRY_CAST(stat_asistencias_valor AS INT) AS val_a,
            stat_blocks_id      AS est_id_b, TRY_CAST(stat_blocks_valor      AS INT) AS val_b,
            stat_defrebs_id     AS est_id_dr,TRY_CAST(stat_defrebs_valor     AS INT) AS val_dr,
            stat_fga_id         AS est_id_fga,TRY_CAST(stat_fga_valor        AS INT) AS val_fga,
            stat_fgm_id         AS est_id_fgm,TRY_CAST(stat_fgm_valor        AS INT) AS val_fgm,
            stat_fouls_id       AS est_id_fl, TRY_CAST(stat_fouls_valor      AS INT) AS val_fl,
            stat_fta_id         AS est_id_fta,TRY_CAST(stat_fta_valor        AS INT) AS val_fta,
            stat_ftm_id         AS est_id_ftm,TRY_CAST(stat_ftm_valor        AS INT) AS val_ftm,
            stat_mins_id        AS est_id_min,TRY_CAST(stat_mins_valor       AS INT) AS val_min,
            stat_offrebs_id     AS est_id_or, TRY_CAST(stat_offrebs_valor    AS INT) AS val_or,
            stat_points_id      AS est_id_pts,TRY_CAST(stat_points_valor     AS INT) AS val_pts,
            stat_secs_id        AS est_id_sec,TRY_CAST(stat_secs_valor       AS INT) AS val_sec,
            stat_steals_id      AS est_id_stl,TRY_CAST(stat_steals_valor     AS INT) AS val_stl,
            stat_tpa_id         AS est_id_tpa,TRY_CAST(stat_tpa_valor        AS INT) AS val_tpa,
            stat_tpm_id         AS est_id_tpm,TRY_CAST(stat_tpm_valor        AS INT) AS val_tpm,
            stat_turnovers_id   AS est_id_to, TRY_CAST(stat_turnovers_valor  AS INT) AS val_to
        FROM Migracion
        WHERE TRY_CAST(playerId AS INT) IS NOT NULL
          AND TRY_CAST(gameId   AS INT) IS NOT NULL
    ),
    UNPIV AS (
        SELECT ID_Jugador, ID_Partido, est_id_a AS ID_Est, val_a AS Cantidad FROM S WHERE est_id_a IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_b , val_b  FROM S WHERE est_id_b  IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_dr, val_dr FROM S WHERE est_id_dr IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_fga,val_fga FROM S WHERE est_id_fga IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_fgm,val_fgm FROM S WHERE est_id_fgm IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_fl , val_fl  FROM S WHERE est_id_fl  IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_fta,val_fta FROM S WHERE est_id_fta IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_ftm,val_ftm FROM S WHERE est_id_ftm IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_min,val_min FROM S WHERE est_id_min IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_or , val_or  FROM S WHERE est_id_or  IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_pts,val_pts FROM S WHERE est_id_pts IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_sec,val_sec FROM S WHERE est_id_sec IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_stl,val_stl FROM S WHERE est_id_stl IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_tpa,val_tpa FROM S WHERE est_id_tpa IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_tpm,val_tpm FROM S WHERE est_id_tpm IS NOT NULL
        UNION ALL SELECT ID_Jugador, ID_Partido, est_id_to , val_to  FROM S WHERE est_id_to  IS NOT NULL
    ),
    CleanStats AS (
        SELECT DISTINCT
            TRY_CAST(Cantidad AS INT)        AS Cantidad,
            ID_Jugador                       AS Jugador_S,
            TRY_CAST(ID_Est AS INT)          AS Estadistica_S,
            ID_Partido                       AS Partido_S
        FROM UNPIV
        WHERE Cantidad IS NOT NULL
    )
    INSERT INTO STATABLE (Cantidad, Jugador_S, Estadistica_S, Partido_S)
    SELECT c.Cantidad, c.Jugador_S, c.Estadistica_S, c.Partido_S
    FROM CleanStats c
    LEFT JOIN STATABLE t
      ON t.Jugador_S = c.Jugador_S AND t.Estadistica_S = c.Estadistica_S AND t.Partido_S = c.Partido_S
    WHERE t.Jugador_S IS NULL;

    /* ==========================================
               JUGADOR_EQUIPO
       ========================================== */
    INSERT INTO Jugador_Equipo (Nro_Camiseta, ID_Jugador, ID_Equipo)
    SELECT DISTINCT
        TRY_CAST(jerseyNo AS INT)      AS Nro_Camiseta,
        TRY_CAST(playerId AS INT)      AS ID_Jugador,
        TRY_CAST(teamid  AS INT)       AS ID_Equipo
    FROM Migracion m
    WHERE TRY_CAST(playerId AS INT) IS NOT NULL
      AND TRY_CAST(teamid  AS INT) IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM Jugador_Equipo je
          WHERE je.ID_Jugador = TRY_CAST(m.playerId AS INT)
            AND je.ID_Equipo  = TRY_CAST(m.teamid  AS INT)
      );

    /* ==========================================
                  JUGADOR_TEMPORADA
       ========================================== */
    INSERT INTO Jugador_Temporada (ID_Jugador, ID_Temporada)
    SELECT DISTINCT
        TRY_CAST(playerId AS INT)      AS ID_Jugador,
        TRY_CAST(seasonId AS INT)      AS ID_Temporada
    FROM Migracion m
    WHERE TRY_CAST(playerId AS INT) IS NOT NULL
      AND TRY_CAST(seasonId AS INT) IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM Jugador_Temporada jt
          WHERE jt.ID_Jugador = TRY_CAST(m.playerId AS INT)
            AND jt.ID_Temporada = TRY_CAST(m.seasonId AS INT)
      );

    COMMIT TRAN;
    PRINT 'Carga finalizada OK';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRAN;
    DECLARE @Err nvarchar(max) = ERROR_MESSAGE();
    RAISERROR('Error en la carga: %s', 16, 1, @Err);
END CATCH;


------------------------------------------------
--ELIMINACION DE ESPACIOS EN BLANCO
------------------------------------------------
-- PAIS 
UPDATE dbo.Pais
SET Nom_Pais = LTRIM(RTRIM(TRANSLATE(Nom_Pais, CHAR(9)+CHAR(160), '  ')));
WHILE EXISTS (SELECT 1 FROM dbo.Pais WHERE Nom_Pais LIKE '%  %')
    UPDATE dbo.Pais SET Nom_Pais = REPLACE(Nom_Pais,'  ',' ') WHERE Nom_Pais LIKE '%  %';

-- CIUDAD 
UPDATE dbo.CIUDAD
SET Nombre_Ciudad = LTRIM(RTRIM(TRANSLATE(Nombre_Ciudad, CHAR(9)+CHAR(160), '  ')));
WHILE EXISTS (SELECT 1 FROM dbo.CIUDAD WHERE Nombre_Ciudad LIKE '%  %')
    UPDATE dbo.CIUDAD SET Nombre_Ciudad = REPLACE(Nombre_Ciudad,'  ',' ') WHERE Nombre_Ciudad LIKE '%  %';

-- EQUIPO 
UPDATE dbo.EQUIPO
SET Nombre_Equipo = LTRIM(RTRIM(TRANSLATE(Nombre_Equipo, CHAR(9)+CHAR(160), '  ')));
WHILE EXISTS (SELECT 1 FROM dbo.EQUIPO WHERE Nombre_Equipo LIKE '%  %')
    UPDATE dbo.EQUIPO SET Nombre_Equipo = REPLACE(Nombre_Equipo,'  ',' ') WHERE Nombre_Equipo LIKE '%  %';

-- JUGADOR
UPDATE dbo.JUGADOR
SET Nombre_Jugador   = LTRIM(RTRIM(TRANSLATE(Nombre_Jugador  , CHAR(9)+CHAR(160), '  '))),
    Apellido_Jugador = LTRIM(RTRIM(TRANSLATE(Apellido_Jugador, CHAR(9)+CHAR(160), '  ')));
WHILE EXISTS (SELECT 1 FROM dbo.JUGADOR WHERE Nombre_Jugador LIKE '%  %')
    UPDATE dbo.JUGADOR SET Nombre_Jugador = REPLACE(Nombre_Jugador,'  ',' ') WHERE Nombre_Jugador LIKE '%  %';
WHILE EXISTS (SELECT 1 FROM dbo.JUGADOR WHERE Apellido_Jugador LIKE '%  %')
    UPDATE dbo.JUGADOR SET Apellido_Jugador = REPLACE(Apellido_Jugador,'  ',' ') WHERE Apellido_Jugador LIKE '%  %';

-----------------------------------------------------------------
-------CONSULTAS
-----------------------------------------------------------------
--1) Cantidad de equipos que jugaron de local el 1 de diciembre

SELECT COUNT(*) AS CANTIDAD_equipos_diciembre_1 FROM Partido
WHERE 1=1 AND MONTH(Fecha_Partido)=12 AND DAY(Fecha_Partido)=1

--2) Cantidad de partidos jugados en noviembre de 2022

SELECT COUNT (*) AS CANTIDAD_partidos_noviembre_2022 FROM Partido
WHERE 1=1 AND YEAR(Fecha_Partido)='2022' AND MONTH(Fecha_Partido)=11 

--3) Cantidad de jugadores que jugaron para los Bulls

SELECT COUNT(*) AS Jugadores_bulls FROM JUGADOR
INNER JOIN Jugador_Equipo ON (Jugador_Equipo.ID_Jugador=JUGADOR.ID_Jugador)
INNER JOIN EQUIPO ON (Jugador_Equipo.ID_Equipo=EQUIPO.ID_Equipo)
WHERE Nombre_Equipo= 'Bulls'

--4) Listado de partidos que se jugaron en noviembre indicando id de partido, fecha, equipo
--local, equipo visitante y los puntos obtenidos por cada uno.

SELECT ID_Partido,Fecha_Partido,Partido_Local,Partido_Visitante,Puntos_Local,Puntos_Visitante FROM Partido
WHERE MONTH(Fecha_Partido)=11

--5)Cantidad de partidos que perdieron los Bucks jugando como local.

SELECT COUNT (*) AS Partidos_Perdidos_BUCKS FROM Partido
WHERE Partido_Local='Bucks' AND Ganador!='Bucks'

--6)Listar los 5 equipos con mayor promedio de rebotes por partido.

SELECT e.Nombre_Equipo, AVG(r.TotalRebotes) AS Promedio_Rebotes
FROM (SELECT 
je.ID_Equipo,
je.ID_Jugador,
SUM(s.Cantidad) AS TotalRebotes
FROM Jugador_Equipo AS je
INNER JOIN STATABLE AS s ON (s.Jugador_S = je.ID_Jugador) AND (s.Estadistica_S IN (3, 10)) 
GROUP BY je.ID_Equipo, je.ID_Jugador
) AS r
INNER JOIN Equipo AS e ON (e.ID_Equipo = r.ID_Equipo)
GROUP BY e.Nombre_Equipo
ORDER BY Promedio_Rebotes DESC;

-- 7) Promedio de puntos por partido de los jugadores agrupados por conferencia

SELECT J.Nombre_Jugador, C.Nombre_Conferencia, AVG(S.Cantidad) as prom_Puntos FROM Jugador as J
INNER JOIN STATABLE as S ON (S.Jugador_S=J.ID_Jugador)
INNER JOIN Partido as P ON (P.ID_Partido=S.Partido_S)
INNER JOIN Tipo_Estadistica as TE ON (TE.ID_Estadistica = S.Estadistica_S)
INNER JOIN Jugador_Equipo as JE ON (JE.ID_jugador=J.ID_Jugador)
INNER JOIN Equipo as E ON (E.ID_Equipo=JE.ID_Equipo)
INNER JOIN Division as D ON(D.ID_Division=E.Div_Equipo)
INNER JOIN Conferencia as C ON (C.ID_Conferencia=D.Conferencia_D)
WHERE TE.Desc_Est ='Puntos'
GROUP BY J.Nombre_Jugador, C.Nombre_Conferencia;

-- 8) Promedio de asistencias por partido de los equipos, agrupados por divisi�n

SELECT ap.Nombre_Division, ap.Nombre_Equipo,
AVG(CAST(ap.AsistenciasEquipoEnPartido AS DECIMAL(10,2))) AS PromedioAsistenciasPorPartido
FROM (SELECT E.ID_Equipo, E.Nombre_Equipo, D.Nombre_Division, P.ID_Partido,
SUM(S.Cantidad) AS AsistenciasEquipoEnPartido FROM EQUIPO AS E
INNER JOIN Jugador_Equipo AS JE ON (JE.ID_Equipo = E.ID_Equipo)
INNER JOIN JUGADOR AS J ON (J.ID_Jugador = JE.ID_Jugador)
INNER JOIN STATABLE AS S ON (S.Jugador_S = J.ID_Jugador)
INNER JOIN Tipo_Estadistica AS TE ON (TE.ID_Estadistica = S.Estadistica_S)
INNER JOIN Partido AS P ON (P.ID_Partido = S.Partido_S)
INNER JOIN Division AS D ON (D.ID_Division = E.Div_Equipo)
WHERE TE.Desc_Est = 'Asistencias'
GROUP BY E.ID_Equipo, E.Nombre_Equipo, D.Nombre_Division, P.ID_Partido
) AS ap
GROUP BY ap.Nombre_Division, ap.Nombre_Equipo
ORDER BY ap.Nombre_Division, PromedioAsistenciasPorPartido DESC;

--9) Indicar nombre del pa�s y cantidad de jugadores, del pa�s con m�s jugadores en el torneo
--(excluyendo Estados Unidos).

SELECT TOP 1 
p.Nom_Pais,COUNT(DISTINCT j.ID_Jugador) AS Cant_Jugadores
FROM Pais AS p
INNER JOIN Jugador AS j ON j.Pais_origen = p.ID_pais
INNER JOIN STATABLE AS s ON s.Jugador_S   = j.ID_Jugador      
INNER JOIN Partido  AS pr ON pr.ID_Partido = s.Partido_S       
WHERE p.Nom_Pais <> 'Estados Unidos'
GROUP BY p.Nom_Pais
ORDER BY Cant_Jugadores DESC; 

--10) Promedio de minutos jugados por cada jugador, de los originarios del pa�s del punto
--anterior. Se considera partido jugado si jug� al menos 1 minuto en el partido.

SELECT pa.Nom_Pais, t.ID_Jugador, t.Nombre_Jugador,COUNT(*) AS Partidos_Jugados,                                   -- s�lo los con >=1 min
AVG(CAST(t.MinutosEnPartido AS DECIMAL(10,2))) AS Prom_Minutos
FROM (SELECT j.ID_Jugador, j.Nombre_Jugador, j.Pais_origen, s.Partido_S,
SUM(s.Cantidad) AS MinutosEnPartido FROM Jugador AS j
INNER JOIN STATABLE AS s ON (s.Jugador_S = j.ID_Jugador)
INNER JOIN Tipo_Estadistica AS te ON (te.ID_Estadistica = s.Estadistica_S)
WHERE te.Desc_Est = 'Minutos' AND j.Pais_origen IN (
SELECT TOP 1 p.ID_pais FROM Pais AS p
INNER JOIN Jugador AS j2 ON (j2.Pais_origen = p.ID_pais)
INNER JOIN Jugador_Equipo AS je ON (je.ID_Jugador = j2.ID_Jugador)
WHERE p.Nom_Pais <> 'Estados Unidos'
GROUP BY p.ID_pais
ORDER BY COUNT(DISTINCT j2.ID_Jugador) DESC)
GROUP BY j.ID_Jugador, j.Nombre_Jugador, j.Pais_origen, s.Partido_S
HAVING SUM(s.Cantidad) >= 1 
) AS t
INNER JOIN Pais AS pa ON pa.ID_pais = t.Pais_origen
GROUP BY pa.Nom_Pais, t.ID_Jugador, t.Nombre_Jugador
ORDER BY Prom_Minutos DESC;

--11) Cantidad de jugadores con m�s de 15 a�os de carrera.

SELECT COUNT(*) AS CANTIDAD_JUGADORES FROM JUGADOR
WHERE DATEDIFF(YEAR,DraftYear,GETDATE())>15

--12) Cantidad de partidos en que los que al menos un jugador de los Suns obtuvo m�s de 18
--puntos.

SELECT COUNT(DISTINCT q.ID_Partido) AS CANT_PARTIDOS
FROM (SELECT s.Partido_S AS ID_Partido FROM STATABLE AS s
INNER JOIN Tipo_Estadistica AS te ON te.ID_Estadistica = s.Estadistica_S
INNER JOIN Jugador AS j ON j.ID_Jugador = s.Jugador_S
INNER JOIN Jugador_Equipo AS je ON je.ID_Jugador  = j.ID_Jugador
INNER JOIN Equipo AS e ON e.ID_Equipo = je.ID_Equipo
WHERE te.Desc_Est = 'Puntos' AND e.Nombre_Equipo = 'Suns'       
GROUP BY s.Partido_S, j.ID_Jugador    
HAVING SUM(s.Cantidad) > 18) AS q;


--13) Listado con ID de partido, fecha, sigla y puntos realizados del equipo local y visitante, del
--partido en que el equipo de Matt Ryan gan� por mayor diferencia de puntos en la
--temporada.

SELECT TOP 1 P.ID_Partido, P.Fecha_Partido AS Fecha, E_Local.Sigla AS Sigla_Local,
P.Puntos_Local, E_Visitante.Sigla AS Sigla_Visitante, P.Puntos_Visitante
FROM Partido P
INNER JOIN Equipo E_Local ON P.Partido_Local = E_Local.Code_Alfa
INNER JOIN Equipo E_Visitante ON P.Partido_Visitante = E_Visitante.Code_Alfa
INNER JOIN Jugador_Equipo JE ON JE.ID_Equipo = E_Local.ID_Equipo OR JE.ID_Equipo = E_Visitante.ID_Equipo
INNER JOIN Jugador J ON JE.ID_Jugador = J.ID_Jugador
WHERE J.Nombre_Jugador = 'Matt' AND J.Apellido_Jugador = 'Ryan'
AND ((E_Local.ID_Equipo = JE.ID_Equipo AND P.Puntos_Local > P.Puntos_Visitante) OR
(E_Visitante.ID_Equipo = JE.ID_Equipo AND P.Puntos_Visitante > P.Puntos_Local))
ORDER BY (ABS(P.Puntos_Local - P.Puntos_Visitante)) DESC;

--14) Listado con el Top 10 de goleadores, indicando nombre del jugador, cantidad de puntos,
--cantidad de partidos jugados, y promedio de puntos por partidos, ordenando por este
--�ltimo criterio para determinar los goleadores.

SELECT TOP 10
J.Nombre_Jugador + ' ' + J.Apellido_Jugador AS Nombre_Jugador,
SUM(S.Cantidad) AS Cantidad_Puntos,
COUNT(DISTINCT S.Partido_S) AS Partidos_Jugados,
CAST(SUM(S.Cantidad) AS FLOAT) / COUNT(DISTINCT S.Partido_S) AS Promedio_Puntos_Por_Partido
FROM JUGADOR J
INNER JOIN STATABLE S ON J.ID_Jugador = S.Jugador_S
INNER JOIN Tipo_Estadistica TE ON S.Estadistica_S = TE.ID_Estadistica
WHERE TE.Desc_Est = 'Puntos'
GROUP BY J.ID_Jugador, J.Nombre_Jugador, J.Apellido_Jugador
HAVING COUNT(DISTINCT S.Partido_S) > 0
ORDER BY Promedio_Puntos_Por_Partido DESC;

--15) Tabla de posiciones finales de los equipos de la conferencia Oeste, indicando nombre del
--equipo, c�digo, cantidad partidos ganaDos, cantidad partidos perdidos, puntos a favor,
--puntos en contra y diferencia de puntos. Ordenando de mayor a menor por cantidad de
--partidos ganados y diferencia de puntos.

SELECT E.Nombre_Equipo, E.Code_Alfa AS Codigo,
SUM(T.Es_Ganador) AS Partidos_Ganados,
SUM(T.Es_Perdedor) AS Partidos_Perdidos,
SUM(T.Puntos_Favor) AS Puntos_A_Favor,
SUM(T.Puntos_Contra) AS Puntos_En_Contra,
(SUM(T.Puntos_Favor) - SUM(T.Puntos_Contra)) AS Diferencia_Puntos
FROM EQUIPO E
INNER JOIN Division D ON E.Div_Equipo = D.ID_Division
INNER JOIN Conferencia C ON D.Conferencia_D = C.ID_Conferencia
INNER JOIN (
SELECT P.Partido_Local AS Equipo_Code_Alfa, P.Puntos_Local AS Puntos_Favor,
P.Puntos_Visitante AS Puntos_Contra,
CAST(SIGN(P.Puntos_Local - P.Puntos_Visitante) AS INT) * 0.5 + 0.5 AS Es_Ganador,
CAST(SIGN(P.Puntos_Visitante - P.Puntos_Local) AS INT) * 0.5 + 0.5 AS Es_Perdedor
FROM Partido P UNION ALL
SELECT P.Partido_Visitante AS Equipo_Code_Alfa, P.Puntos_Visitante AS Puntos_Favor,
P.Puntos_Local AS Puntos_Contra,
CAST(SIGN(P.Puntos_Visitante - P.Puntos_Local) AS INT) * 0.5 + 0.5 AS Es_Ganador,
CAST(SIGN(P.Puntos_Local - P.Puntos_Visitante) AS INT) * 0.5 + 0.5 AS Es_Perdedor
FROM Partido P) AS T ON E.Code_Alfa = T.Equipo_Code_Alfa 
WHERE C.Nombre_Conferencia = 'Oeste'
GROUP BY E.ID_Equipo, E.Nombre_Equipo, E.Code_Alfa
ORDER BY Partidos_Ganados DESC, Diferencia_Puntos DESC;