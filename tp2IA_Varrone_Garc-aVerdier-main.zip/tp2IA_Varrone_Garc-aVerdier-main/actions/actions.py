from typing import Any, Text, Dict, List
import requests
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet

class ActionConsultarTicketLongvie(Action):
    """
    Custom Action para consultar el estado de un ticket técnico consumiendo una API externa.
    """

    def name(self) -> Text:
        return "action_consultar_ticket_longvie"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        # Recuperamos el slot del número de ticket
        numero_ticket = tracker.get_slot("numero_ticket")
        
        if not numero_ticket:
            dispatcher.utter_message(text="No se ha proporcionado un número de ticket válido.")
            return []

        # Intentamos conectar a la API mock
        try:
            # Usamos jsonplaceholder para simular la búsqueda del ticket
            url = f"https://jsonplaceholder.typicode.com/todos/{numero_ticket}"
            response = requests.get(url, timeout=5)
            
            # Verificamos que la petición HTTP fue exitosa
            response.raise_for_status()
            data = response.json()
            
            # Simulamos lógica de negocio: si "completed" es True, está "Resuelto", si no, "En Proceso"
            estado = "Resuelto" if data.get("completed") else "En Proceso"
            
            # Respuesta corporativa
            mensaje = (f"Estimado cliente, hemos verificado en nuestra base de datos. "
                       f"El estado actual de su reclamo técnico número {numero_ticket} es: {estado}. "
                       f"¿Hay algo más en lo que le pueda ayudar?")
            
            dispatcher.utter_message(text=mensaje)
            
        except requests.exceptions.HTTPError:
            # Manejo de error específico HTTP (ej: 404 No encontrado)
            dispatcher.utter_message(
                text=f"Lo sentimos, no hemos podido encontrar el ticket número {numero_ticket} en nuestros registros."
            )
        except requests.exceptions.RequestException:
            # Manejo general de excepciones de red
            dispatcher.utter_message(
                text="Disculpe las molestias. En este momento estamos experimentando problemas de conexión "
                     "con nuestro sistema de servicio técnico. Por favor, intente más tarde."
            )
        
        # Limpiamos el slot para futuras consultas en la misma sesión
        return [SlotSet("numero_ticket", None)]
